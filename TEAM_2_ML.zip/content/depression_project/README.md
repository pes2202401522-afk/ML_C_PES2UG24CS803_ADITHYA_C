# Interpretable Depression Diagnosis from Brain Imaging

## Overview
This project develops a machine learning model to diagnose depression using fMRI data, transitioning from synthetic to real data from the Kaggle dataset "Depression Detection Using MRI." It employs Logistic Regression, Decision Tree, and SVM models, focusing on interpretability. The project was implemented in Google Colab.

## Installation
1. Clone the repository: `git clone <your-repo-url>`
2. Install dependencies: `pip install -r requirements.txt` (create this file below).
3. Download the Kaggle dataset: [Depression Detection Using MRI](https://www.kaggle.com/datasets/anshumanprabhakar/depression-detection-using-mri) and place it in `data/raw/`.
4. Open `Depression_Diagnosis.ipynb` in Jupyter Notebook or Colab to run the pipeline.

## Project Structure
- `Depression_Diagnosis.ipynb`: Main notebook with data processing, modeling, and evaluation.
- `ui.py`: Streamlit app for demoing predictions.
- `data/processed/`: Processed CSV file (`processed_mri_data.csv`) with extracted features.
- `figures/`: Visualization files (e.g., `decision_tree.png`, `confusion_matrix.png`).
- `model/`: Saved models and scaler (e.g., `lr_model.pkl`, `scaler.pkl`).

## Running the Project
1. Execute `Depression_Diagnosis.ipynb` cells sequentially to preprocess data, train models, and generate figures.
2. Run the UI: Install Streamlit (`pip install streamlit`) and use ngrok or localtunnel:
   - Ngrok: Follow setup in notebook comments.
   - Localtunnel: `!streamlit run ui.py & npx localtunnel --port 8501` with IP password.
3. Upload an MRI file to the UI for prediction.

## Dependencies
Create a `requirements.txt` file with:
```plaintext
numpy
pandas
scikit-learn
matplotlib
seaborn
nibabel
nilearn
torch
torchvision
streamlit
joblib
