# %%writefile ui.py
import streamlit as st
import nibabel as nib
from nilearn.input_data import NiftiLabelsMasker
from nilearn import image, datasets
import numpy as np
import joblib
import os

# Load atlas
atlas = datasets.fetch_atlas_harvard_oxford('cort-maxprob-thr25-2mm')
masker = NiftiLabelsMasker(labels_img=atlas.maps, strategy='mean', standardize=False)

# Load pretrained model, scaler, and selector
model = joblib.load('/content/model/lr_model.pkl')
scaler = joblib.load('/content/model/scaler.pkl')
selector = joblib.load('/content/model/selector.pkl')

st.title("Depression Diagnosis Demo from MRI")

uploaded_file = st.file_uploader("Upload MRI (.nii or .nii.gz)", type=['nii', 'gz'])

if uploaded_file:
    # Save temp file
    with open('/content/temp.nii', 'wb') as f:
        f.write(uploaded_file.getvalue())
    
    img = nib.load('/content/temp.nii')
    print(f"Original shape of uploaded file: {img.shape}")  # Debug
    
    # Resample to atlas space
    resampled_img = image.resample_to_img(img, atlas.maps, interpolation='nearest', copy_header=True)
    print(f"Resampled shape: {resampled_img.shape}")  # Debug
    
    time_series = masker.fit_transform(resampled_img)
    print(f"Time series shape: {time_series.shape}")  # Debug
    
    # Handle 1D time series
    if len(time_series.shape) == 1 and len(time_series) >= 20:
        mean_signal = time_series[:20]
    else:
        mean_signal = np.pad(time_series, (0, 20 - len(time_series)), mode='constant')
    
    # Preprocess
    features = scaler.transform([mean_signal])
    features_selected = selector.transform(features)
    
    pred = model.predict(features_selected)[0]
    prob = model.predict_proba(features_selected)[0][1]
    
    st.write(f"Prediction: {'Depressed' if pred == 1 else 'Healthy'} (Probability: {prob:.2f})")
    coef = model.coef_[0]
    top_idx = np.argsort(np.abs(coef))[-3:]
    st.write("Top contributing features:")
    for idx in top_idx:
        st.write(f"- ROI {idx}: Coefficient {coef[idx]:.2f}")